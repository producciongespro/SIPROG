<?php
	$db_host = 'localhost'; //Host del Servidor MySQL
	$db_name = 'recursos_siprog'; //Nombre de la Base de datos
	$db_user = 'recursos_gespro'; //Usuario de MySQL
	$db_pass = 'Hola123Gespro'; //Password de Usuario MySQL
$project="siprog";
$backup_file = "$project-" . date("Y-m-d-H-i-s") . ".sql.gz";
$command = "mysqldump --opt -h db_host -u $db_user -p $db_pass $db_name | gzip > $backup_file";

system($command,$output);
?>
